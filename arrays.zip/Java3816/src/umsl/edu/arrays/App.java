package umsl.edu.arrays;

public class App {

	public static void main(String[] args) {

		App main = new App();
		Book[] books = new Book[3];
		books[0] = new Book("The Da Vinci Code", "Dan Brown", "Fiction");
		books[1] = new Book("Harry Potter", "J.K. Rowling", "Fiction");
		books[2] = new Book("The Lost Symbol", "Dan Brown", "Fiction");
		main.processArray(books);
	}

	public void processArray(Book[] books) {
		for (int i = 0; i < books.length; i++) {
			System.out.println(books[i].bookName);
		}

	}
}
